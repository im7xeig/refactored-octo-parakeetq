#!/bin/bash

while true
do
  curl "https://9000-firebase-th-1759255400405.cluster-hllxpfasbba62ri4b2ygaupuxu.cloudworkstations.dev/"
  echo ""  # فقط برای رفتن به خط جدید
  sleep 60 # هر 60 ثانیه (1 دقیقه)
done
