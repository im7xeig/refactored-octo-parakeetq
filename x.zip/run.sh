#!/bin/bash
./tt.sh && ./r.sh && ./bash.sh && ./ht.py -t 8